﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;
using Newtonsoft.Json.Linq;
using Microsoft.JScript;
using Convert = Microsoft.JScript.Convert;
using System.Linq;
using Avensia.Storefront.Developertest;

namespace Avensia.Storefront.Developertest
{
    public class ProductListVisualizer
    {
        private readonly IProductRepository _productRepository;
        
        private string _json = Path.GetFileName(@"C:\inetpub\wwwroot\avensia\avensia.developer-challenge-master\backend\products.json");

        private string _line = new string('-', 70);
        private int _ctr = 0;
        public List<ProductListVisualizer> items { get; set; }

        public ProductListVisualizer(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public void OutputAllProduct()
        {
            /*
            var products = _productRepository.GetProducts();
            foreach (var product in products)
            {
                Console.WriteLine($"{product.Id}\t{product.Name}\t{product.Price}");
            }
           */
           var json = File.ReadAllText(_json.ToString());
            JArray _jsonVal = JArray.Parse(json) as JArray;
            dynamic products = _jsonVal;

            foreach (dynamic product in products)
            {
                _ctr++;
                Console.WriteLine("#:" + _ctr + ". ID:" + product.Id + ", Name:" + product.ProductName + ", Price:" + string.Format("{0:N2}", Convert.ToInt32(product.Price)));
                foreach (dynamic pro in product.Properties)
                {
                    Console.WriteLine("\t" + pro.KeyName + ":" + pro.Value);
                }
                Console.WriteLine("" + _line);
            }
            _ctr = 0;
        }

        public void OutputPaginatedProducts()
        {
            //throw new NotImplementedException();
            int pageSize = 5, pageCounter = 0;
            int totcnt = 0;
            var json = File.ReadAllText(_json.ToString());
            var groups = JArray.Parse(json).GroupBy(x => x.Value<string>("Id"));
            totcnt = groups.Count();

            Console.WriteLine("Total counts:" + totcnt);
            Console.WriteLine("" + _line);

            var pageItems = groups.Take(pageSize);
            while (pageItems.Count() > 0)
            {
                foreach (var data in groups)
                {
                    foreach (var item in data)
                    {
                        _ctr++;
                        Console.WriteLine("\t" + "#:" + _ctr + "." + "Id:" + item["Id"]);
                        Console.WriteLine("\t" + "Name:" + item["ProductName"]);
                        Console.WriteLine("\t" + "Price:" + item["Price"]);
                        Console.WriteLine("" + _line);
                    }
                    pageCounter++;
                    Console.WriteLine("Press any key to get the next items...");
                    Console.ReadKey();
                    // Here's where we use the Skip() and Take() methods!                    
                    pageItems = groups.Skip((pageSize-1) * pageCounter).Take(pageSize).ToList();
                }
                _ctr = 0;
            }            

            Console.WriteLine("Nothing follows ...");
        }

    public void OutputProductGroupedByPriceSegment()
        {
            //throw new NotImplementedException();

            var json = File.ReadAllText(_json.ToString());
            var groups = JArray.Parse(json).GroupBy(x => x.Value<string>("Price"));

            Console.WriteLine("Group count: {0}.  Groups:", groups.Count());
            foreach (var data in groups)
            {
                Console.WriteLine("" + _line);
                Console.WriteLine("Price Group:" + string.Format("{0:N2}", Convert.ToInt32(data.Key)));
                foreach (var item in data)
                {
                    Console.WriteLine("\t" + item["ProductName"]);
                }
            }

        }
    }
}